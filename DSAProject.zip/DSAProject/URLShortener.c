#include "URLShortener.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

URLPair table[hash_table_size]; // Define table here

int hash(char* str) {
    int hash = 0;
    for (int i = 0; str[i]; i++)
        hash = (hash * 31 + str[i]) % hash_table_size;
    return hash;
}

void generateShortURL(char* long_url, char* short_url) {
    int hash_index = hash(long_url);
    int i = 0;
    while (table[(hash_index + i) % hash_table_size].long_url[0])
        i++;
    sprintf(short_url, "%d%d%d", hash_index, i, rand() % 100);
}

void storeURL(char* long_url) {
    char short_url[short_len];
    generateShortURL(long_url, short_url);
    int index = hash(long_url);
    strcpy(table[index].long_url, long_url);
    strcpy(table[index].short_url, short_url);
}

char* getLongURL(char* short_url) {
    for (int i = 0; i < hash_table_size; i++)
        if (!strcmp(table[i].short_url, short_url))
            return table[i].long_url;
    return NULL;
}

void loadTable() {
    FILE* fp = fopen("table.txt", "r");
    if (fp == NULL)
        return;
    int index = 0;
    while (fscanf(fp, "%s %s", table[index].long_url, table[index].short_url) != EOF)
        index++;
    fclose(fp);
}

void saveTable() {
    FILE* fp = fopen("table.txt", "w");
    if (fp == NULL)
        return;
    for (int i = 0; i < hash_table_size; i++)
        if (table[i].long_url[0])
            fprintf(fp, "%s %s\n", table[i].long_url, table[i].short_url);
    fclose(fp);
}

