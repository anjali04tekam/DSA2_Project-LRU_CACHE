#include "LRUCache.h"
#include <stdlib.h>
#include <stdio.h>

int hashFunction(int key) {
    return key % HASH_SIZE;
}

ListNode* createNode(int key, int val) {
    ListNode* newNode = (ListNode*)malloc(sizeof(ListNode));
    newNode->key = key;
    newNode->val = val;
    newNode->prev = NULL;
    newNode->next = NULL;
    return newNode;
}

LRUCache* createLRUCache(int capacity) {
    LRUCache* cache = (LRUCache*)malloc(sizeof(LRUCache));
    cache->head = NULL;
    cache->tail = NULL;
    cache->num_nodes = 0;
    cache->capacity = capacity;
    pthread_mutex_init(&(cache->mutex), NULL);
    for (int i = 0; i < HASH_SIZE; i++) {
        cache->hashmap[i] = NULL;
    }
    return cache;
}

int get(LRUCache* cache, int key) {
    pthread_mutex_lock(&(cache->mutex));
    int index = hashFunction(key);
    HashMapNode* current = cache->hashmap[index];
    while (current != NULL) {
        if (current->key == key) {
            ListNode* node = current->node;
            int value = node->val;
            if (node != cache->head) {
                if (node == cache->tail) {
                    cache->tail = node->prev;
                    node->prev->next = NULL;
                } else {
                    node->prev->next = node->next;
                    node->next->prev = node->prev;
                }
                node->next = cache->head;
                node->prev = NULL;
                cache->head->prev = node;
                cache->head = node;
            }
            pthread_mutex_unlock(&(cache->mutex));
            return value;
        }
        current = current->next;
    }
    pthread_mutex_unlock(&(cache->mutex));
    return -1;
}

void put(LRUCache* cache, int key, int value) {
    pthread_mutex_lock(&(cache->mutex));
    int index = hashFunction(key);
    HashMapNode* current = cache->hashmap[index];
    while (current != NULL) {
        if (current->key == key) {
            ListNode* node = current->node;
            node->val = value;
            get(cache, key);
            pthread_mutex_unlock(&(cache->mutex));
            return;
        }
        current = current->next;
    }
    if (cache->num_nodes == cache->capacity) {
        ListNode* temp = cache->tail;
        cache->tail = cache->tail->prev;
        if (cache->tail != NULL) {
            cache->tail->next = NULL;
        } else {
            cache->head = NULL;
        }
        int evictIndex = hashFunction(temp->key);
        HashMapNode* prev = NULL;
        HashMapNode* current = cache->hashmap[evictIndex];
        while (current != NULL) {
            if (current->key == temp->key) {
                if (prev != NULL) {
                    prev->next = current->next;
                } else {
                    cache->hashmap[evictIndex] = current->next;
                }
                free(current);
                break;
            }
            prev = current;
            current = current->next;
        }
        free(temp);
        cache->num_nodes--;
    }
    ListNode* newNode = createNode(key, value);
    newNode->next = cache->head;
    if (cache->head != NULL) {
        cache->head->prev = newNode;
    }
    cache->head = newNode;
    if (cache->tail == NULL) {
        cache->tail = newNode;
    }
    HashMapNode* hashmapNode = (HashMapNode*)malloc(sizeof(HashMapNode));
    hashmapNode->key = key;
    hashmapNode->node = newNode;
    hashmapNode->next = cache->hashmap[index];
    cache->hashmap[index] = hashmapNode;
    cache->num_nodes++;
    pthread_mutex_unlock(&(cache->mutex));
}

void displayCache(LRUCache* cache) {
    pthread_mutex_lock(&(cache->mutex));
    ListNode* current = cache->head;
    printf("Cache contents:\n");
    while (current != NULL) {
        printf("(%d, %d) ", current->key, current->val);
        current = current->next;
    }
    printf("\n");
    pthread_mutex_unlock(&(cache->mutex));
}

void destroyCache(LRUCache* cache) {
    pthread_mutex_destroy(&(cache->mutex));
    free(cache);
}

void destroyLRUCache(LRUCache* cache) {
    pthread_mutex_lock(&(cache->mutex));
    ListNode* current = cache->head;
    while (current != NULL) {
        ListNode* next = current->next;
        free(current);
        current = next;
    }
    for (int i = 0; i < HASH_SIZE; i++) {
        HashMapNode* current = cache->hashmap[i];
        while (current != NULL) {
            HashMapNode* next = current->next;
            free(current);
            current = next;
        }
    }
    pthread_mutex_unlock(&(cache->mutex));
    pthread_mutex_destroy(&(cache->mutex));
    free(cache);
}

