#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LRUCache.h"
#include "URLShortener.h"

int main() {
    int choice;
    LRUCache* cache = NULL;
    loadTable(); // Load URL mappings from table.txt
    do {
        printf("\nMenu:\n");
        printf("1. Cache Memory Simulation\n");
        printf("2. URL Shortening\n");
        printf("3. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                if (cache == NULL) {
                    int capacity;
                    printf("Enter cache capacity: ");
                    scanf("%d", &capacity);
                    cache = createLRUCache(capacity);
                }
                int cache_choice;
                do {
                    printf("\nCache Memory Simulation Menu:\n");
                    printf("1. Add data to cache\n");
                    printf("2. Get data from cache\n");
                    printf("3. Display cache\n");
                    printf("4. Destroy cache and back to main menu\n"); // Modified option
                    printf("Enter your choice: ");
                    scanf("%d", &cache_choice);
                    switch (cache_choice) {
                        case 1:
                            printf("Enter key and value to add to cache: ");
                            int key, value;
                            scanf("%d %d", &key, &value);
                            put(cache, key, value);
                            printf("Data added to cache.\n");
                            break;
                        case 2:
                            printf("Enter key to get data from cache: ");
                            scanf("%d", &key);
                            value = get(cache, key);
                            if (value == -1) {
                                printf("Data not found in cache.\n");
                            } else {
                                printf("Value found in cache: %d\n", value);
                            }
                            break;
                        case 3:
                            displayCache(cache);
                            break;
                        case 4:
                            printf("Destroying cache...\n");
                            destroyCache(cache); // Call the destroyCache function
                            cache = NULL; // Set cache pointer to NULL
                            printf("Cache destroyed. Returning to main menu...\n");
                            break;
                        default:
                            printf("Invalid choice. Please try again.\n");
                    }
                } while (cache_choice != 4);
                break;
            case 2:
                printf("* * * * * * * * * * * * * * * * * * * * * *\n");
                printf("*            URL Shortening Menu           *\n");
                printf("* * * * * * * * * * * * * * * * * * * * * *\n\n");
                char long_url[10000];
                printf("Enter a long URL: ");
                scanf("%s", long_url);
                char* short_url = NULL;
                int index = hash(long_url);
                for (int i = 0; i < hash_table_size; i++) {
                    if (!strcmp(table[(index + i) % hash_table_size].long_url, long_url)) {
                        short_url = table[(index + i) % hash_table_size].short_url;
                        break;
                    }
                }
                if (!short_url) {
                    storeURL(long_url);
                    short_url = table[hash(long_url)].short_url;
                    saveTable();
                }
                printf("Short URL: http://tiny.url/%s\n", short_url);
                char* retrieved_long_url = getLongURL(short_url);
                printf("Retrieved Long URL: %s\n", retrieved_long_url);
                break;
            case 3:
                printf("Exiting...\n");
                if (cache != NULL) {
                    destroyLRUCache(cache);
                }
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 3);
    return 0;
}

